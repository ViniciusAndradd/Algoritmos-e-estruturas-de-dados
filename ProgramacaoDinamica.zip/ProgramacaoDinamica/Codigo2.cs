﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacaoDinamica
{
    public class Codigo2
    {
        static int[,] Tabela;
        static Dictionary<(int, int), HashSet<string>> memoizacao;
        public void comeco()
        {
            Console.WriteLine("Digite a quantidade de conjunto de dados:");
            int D = int.Parse(Console.ReadLine());

            for (int d = 0; d < D; d++)
            {
                Console.WriteLine("Insira a primeira sequência:");
                string primeiraSequencia = Console.ReadLine();
                Console.WriteLine("Insira a segunda sequência:");
                string segundaSequencia = Console.ReadLine();

                int tamPrimeiraSequencia = primeiraSequencia.Length;
                int tamSegundaSequencia = segundaSequencia.Length;

                Tabela = new int[tamPrimeiraSequencia + 1, tamSegundaSequencia + 1];
                memoizacao = new Dictionary<(int, int), HashSet<string>>();

                // Passo 1: construir tabela 
                for (int i = 1; i <= tamPrimeiraSequencia; i++)
                {
                    for (int j = 1; j <= tamSegundaSequencia; j++)
                    {
                        if (primeiraSequencia[i - 1] == segundaSequencia[j - 1])
                        {
                            Tabela[i, j] = Tabela[i - 1, j - 1] + 1;
                        }
                        else
                        {
                            Tabela[i, j] = Math.Max(Tabela[i - 1, j], Tabela[i, j - 1]);
                        }
                            
                    }
                }

                // Passo 2: gerar todas as subsequências mais longas
                var subseqs = GetAllLCS(primeiraSequencia, segundaSequencia, tamPrimeiraSequencia, tamSegundaSequencia);

                // Ordenar e imprimir
                var list = subseqs.ToList();
                list.Sort();
                int ordem = 1;
                foreach (var s in list)
                {
                    Console.WriteLine($"Subsequencia {ordem}");
                    Console.WriteLine(s);
                    ordem++;
                }
                    

                if (d != D - 1)
                    Console.WriteLine(); // linha em branco entre blocos
            }
        }

        static HashSet<string> GetAllLCS(string primeira, string segunda, int tamPrimeira, int tamSegunda)
        {
            //Se as sequências são vazias ele retorna a lista vazia
            if (tamPrimeira == 0 || tamSegunda == 0)
            {
                return new HashSet<string> { "" };
            }

            //Se ele contém a posição ela é retornada
            if (memoizacao.ContainsKey((tamPrimeira, tamSegunda)))
            {
                return memoizacao[(tamPrimeira, tamSegunda)];
            }
                

            var result = new HashSet<string>();

            if (a[i - 1] == b[j - 1])
            {
                foreach (var s in GetAllLCS(a, b, i - 1, j - 1))
                    result.Add(s + a[i - 1]);
            }
            else
            {
                if (dp[i - 1, j] >= dp[i, j - 1])
                    result.UnionWith(GetAllLCS(a, b, i - 1, j));

                if (dp[i, j - 1] >= dp[i - 1, j])
                    result.UnionWith(GetAllLCS(a, b, i, j - 1));
            }

            memo[(i, j)] = result;
            return result;
        }
    }
}
