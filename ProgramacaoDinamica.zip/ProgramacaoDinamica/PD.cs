﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacaoDinamica
{
    internal class PD
    {
        static int[,] dp;

        static void Main()
        {
            Console.WriteLine("Digite a quantidade de conjunto de dados:");
            int D = int.Parse(Console.ReadLine());

            for (int d = 0; d < D; d++)
            {
                Console.WriteLine("Insira a primeira sequência:");
                string a = Console.ReadLine();
                Console.WriteLine("Insira a segunda sequência:");
                string b = Console.ReadLine();

                int n = a.Length;
                int m = b.Length;

                dp = new int[n + 1, m + 1];

                // Passo 1: Construir tabela DP
                for (int i = 1; i <= n; i++)
                {
                    for (int j = 1; j <= m; j++)
                    {
                        if (a[i - 1] == b[j - 1])
                            dp[i, j] = dp[i - 1, j - 1] + 1;
                        else
                            dp[i, j] = Math.Max(dp[i - 1, j], dp[i, j - 1]);
                    }
                }

                int lcsLength = dp[n, m];

                // Passo 2: Simular backtracking usando BFS
                var result = new SortedSet<string>();
                var queue = new Queue<(int i, int j, string s)>();
                queue.Enqueue((n, m, ""));

                var visited = new HashSet<(int, int, string)>();

                while (queue.Count > 0)
                {
                    var (i, j, s) = queue.Dequeue();

                    if (i == 0 || j == 0)
                    {
                        if (s.Length == lcsLength)
                            result.Add(new string(s.Reverse().ToArray()));
                        continue;
                    }

                    if (a[i - 1] == b[j - 1])
                    {
                        var next = (i - 1, j - 1, s + a[i - 1]);
                        if (!visited.Contains(next))
                        {
                            visited.Add(next);
                            queue.Enqueue(next);
                        }
                    }
                    else
                    {
                        if (dp[i - 1, j] >= dp[i, j - 1])
                        {
                            var next = (i - 1, j, s);
                            if (!visited.Contains(next))
                            {
                                visited.Add(next);
                                queue.Enqueue(next);
                            }
                        }
                        if (dp[i, j - 1] >= dp[i - 1, j])
                        {
                            var next = (i, j - 1, s);
                            if (!visited.Contains(next))
                            {
                                visited.Add(next);
                                queue.Enqueue(next);
                            }
                        }
                    }
                }

                // Imprimir resultado
                foreach (var seq in result)
                    Console.WriteLine(seq);

                if (d != D - 1)
                    Console.WriteLine(); // linha em branco entre conjuntos
            }
        }
    }

}

