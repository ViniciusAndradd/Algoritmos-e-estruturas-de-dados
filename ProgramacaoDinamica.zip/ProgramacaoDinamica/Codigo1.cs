﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacaoDinamica
{
    public class Codigo1 //Aqui ele está só preenchendo e imprimindo a tabela
    {
        public void LCS()
        {
            Console.WriteLine("Digite a quantidade de conjunto de dados:");
            int D = int.Parse(Console.ReadLine());

            for (int d = 0; d < D; d++)
            {
                Console.WriteLine("Insira a primeira sequência:");
                string primeiraSequencia = Console.ReadLine();
                Console.WriteLine("Insira a segunda sequência:");
                string segundaSequencia = Console.ReadLine();

                int tamPrimeiraSequencia = primeiraSequencia.Length;
                int tamSegundaSequencia = segundaSequencia.Length;

                int[,] tabela = new int[tamPrimeiraSequencia + 1, tamSegundaSequencia + 1];

                // Preencher tabela DP
                for (int i = 1; i <= tamPrimeiraSequencia; i++)
                {
                    for (int j = 1; j <= tamSegundaSequencia; j++)
                    {
                        if (primeiraSequencia[i - 1] == segundaSequencia[j - 1])
                        {
                            tabela[i, j] = tabela[i - 1, j - 1] + 1;
                        }
                        else
                        {
                            tabela[i, j] = Math.Max(tabela[i - 1, j], tabela[i, j - 1]);
                        }

                    }
                }

                // Impressão da tabela
                Console.WriteLine("Tabela DP:");
                for (int i = 0; i <= tamPrimeiraSequencia; i++)
                {
                    for (int j = 0; j <= tamSegundaSequencia; j++)
                    {
                        Console.Write(tabela[i, j] + " ");
                    }
                    Console.WriteLine();
                }

                // Exibir comprimento da LCS
                Console.WriteLine($"\nComprimento da LCS: {tabela[tamPrimeiraSequencia, tamSegundaSequencia]}");

                if (d != D - 1)
                    Console.WriteLine();
            }
        }
    }
}

