﻿namespace ProgramacaoDinamica
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Codigo1 codigo1 = new Codigo1();
            //codigo1.LCS();


            Codigo2 codigo2 = new Codigo2();
            codigo2.comeco();
        }
    }
}
