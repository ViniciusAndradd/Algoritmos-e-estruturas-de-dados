﻿namespace ProgramacaoDinamica
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //PD codigo1 = new PD();
            //codigo1.LCS();

            PDBacktracking codigo2 = new PDBacktracking();
            codigo2.comeco();
        }
    }
}
